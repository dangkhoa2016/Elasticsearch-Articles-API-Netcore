CREATE TABLE IF NOT EXISTS "schema_migrations" ("version" varchar NOT NULL PRIMARY KEY);

CREATE TABLE IF NOT EXISTS "ar_internal_metadata" ("key" varchar NOT NULL PRIMARY KEY, "value" varchar, "created_at" datetime NOT NULL, "updated_at" datetime NOT NULL);

CREATE TABLE IF NOT EXISTS "articles" ("id" integer PRIMARY KEY AUTOINCREMENT NOT NULL, "title" varchar, "content" text, "published_on" date, "created_at" datetime NOT NULL, "updated_at" datetime NOT NULL, "abstract" text, "url" varchar, "shares" integer);

CREATE TABLE sqlite_sequence(name,seq);

CREATE TABLE IF NOT EXISTS "categories" ("id" integer PRIMARY KEY AUTOINCREMENT NOT NULL, "title" varchar, "created_at" datetime NOT NULL, "updated_at" datetime NOT NULL);

CREATE TABLE IF NOT EXISTS "authors" ("id" integer PRIMARY KEY AUTOINCREMENT NOT NULL, "first_name" varchar, "last_name" varchar, "created_at" datetime NOT NULL, "updated_at" datetime NOT NULL);

CREATE TABLE IF NOT EXISTS "authorships" (
  "id" integer PRIMARY KEY AUTOINCREMENT NOT NULL, 
  "article_id" integer, 
  "author_id" integer, 
  "created_at" datetime NOT NULL, 
  "updated_at" datetime NOT NULL, 
  CONSTRAINT "fk_authorships_on_article_id" FOREIGN KEY ("article_id") REFERENCES "articles" ("id"), 
  CONSTRAINT "fk_authorships_on_author_id" FOREIGN KEY ("author_id") REFERENCES "authors" ("id")
);
CREATE INDEX "index_authorships_on_article_id" ON "authorships" ("article_id");
CREATE INDEX "index_authorships_on_author_id" ON "authorships" ("author_id");

CREATE TABLE IF NOT EXISTS "comments" (
  "id" integer PRIMARY KEY AUTOINCREMENT NOT NULL, 
  "body" text, 
  "user" varchar, 
  "user_location" varchar, 
  "stars" integer, 
  "pick" boolean, 
  "article_id" integer, 
  "created_at" datetime NOT NULL, 
  "updated_at" datetime NOT NULL, 
  CONSTRAINT "fk_comments_on_article_id" FOREIGN KEY ("article_id") REFERENCES "articles" ("id")
);
CREATE INDEX "index_comments_on_article_id" ON "comments" ("article_id");

CREATE TABLE IF NOT EXISTS "articles_categories" (
  "id" integer PRIMARY KEY AUTOINCREMENT NOT NULL, 
  "article_id" integer, 
  "category_id" integer, 
  CONSTRAINT "fk_articles_categories_on_article_id" FOREIGN KEY ("article_id") REFERENCES "articles" ("id"), 
  CONSTRAINT "fk_articles_categories_on_category_id" FOREIGN KEY ("category_id") REFERENCES "categories" ("id")
);
CREATE INDEX "index_articles_categories_on_article_id" ON "articles_categories" ("article_id");
CREATE INDEX "index_articles_categories_on_category_id" ON "articles_categories" ("category_id");
